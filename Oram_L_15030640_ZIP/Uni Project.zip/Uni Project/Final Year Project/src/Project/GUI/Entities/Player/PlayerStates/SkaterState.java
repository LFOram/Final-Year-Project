package Project.GUI.Entities.Player.PlayerStates;

import Project.GUI.Entities.Player.Player;

import java.util.ArrayList;

public abstract class SkaterState {
//    public ArrayList<Player> getPlayers(){
//
//    }


}
