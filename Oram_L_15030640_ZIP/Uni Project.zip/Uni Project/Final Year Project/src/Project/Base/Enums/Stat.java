package Project.Base.Enums;

/**
 * Created by Leon on 04/12/2018.
 */
public enum Stat {
SChecking, SFighting,SDiscipline,SSkating,SStrength,SEndurance,SPuckHandling,SFaceOffs,SPassing,SScoring,SDefence,SPenaltyShot,
GSkating,GEndurance,GSize,GAgility,GReboundControl,GStyleControl,GHandSpeed,GPuckHandling,GPenaltyShot
}
