package Project.Base.Enums;

/**
 * Created by Leon on 02/12/2018.
 */
public enum Team {
    BUF,HAM,MAN,MIN,TOR,WKP,CAL,EDM,LAP,SFP,SEA,TEX,WIN,ANC,COL,DET,HAL,KEL,MON,STL,VAN
}
