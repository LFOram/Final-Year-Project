package Project.Base.Enums;

public enum Possession {
    HOME,AWAY,FACEOFF,LOOSE
}
