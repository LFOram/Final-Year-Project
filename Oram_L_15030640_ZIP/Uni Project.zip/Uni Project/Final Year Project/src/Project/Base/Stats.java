package Project.Base;

/**
 * Created by Leon on 21/01/2019.
 */
public abstract class Stats {
}
